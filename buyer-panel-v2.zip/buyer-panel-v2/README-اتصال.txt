این بسته برای پروژه:
C:\xampp\htdocs\digitalshop

فایل‌های قابل ویرایش:
C:\xampp\htdocs\digitalshop\app\Http\Controllers\AccountController.php
C:\xampp\htdocs\digitalshop\resources\views\account\layout.blade.php
C:\xampp\htdocs\digitalshop\resources\views\account\dashboard.blade.php
C:\xampp\htdocs\digitalshop\resources\views\account\orders.blade.php
C:\xampp\htdocs\digitalshop\resources\views\account\order-show.blade.php
C:\xampp\htdocs\digitalshop\resources\views\account\files.blade.php
C:\xampp\htdocs\digitalshop\resources\views\account\wallet.blade.php
C:\xampp\htdocs\digitalshop\resources\views\account\notifications.blade.php
C:\xampp\htdocs\digitalshop\resources\views\account\profile.blade.php
C:\xampp\htdocs\digitalshop\resources\views\account\security.blade.php
C:\xampp\htdocs\digitalshop\public\css\account.css

Routes را در:
C:\xampp\htdocs\digitalshop\routes\web.php
داخل Route::middleware('auth')->group(...) قرار دهید.

این پنل از مدل‌های موجود Order, OrderItem, Payment, Download و User::wallet / User::walletTopups و Laravel Notifications استفاده می‌کند.

هیچ email در پنل خریدار استفاده نشده است.

ارتباط‌های واقعی:
Checkout: /checkout و checkout.payment از جریان موجود پروژه
Order: account.orders و account.orders.show
Payment: payment.pay برای سفارش‌های پرداخت‌نشده
Wallet: wallet.index و wallet.topup از سیستم موجود
Downloads: download/{item} با OrderItem واقعی
Notifications: User notifications واقعی
Invoice: account.invoice موجود
